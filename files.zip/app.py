"""
PulmoScan AI — Flask Backend
============================
Serves the HTML frontend and exposes a /analyze endpoint
that runs the full U-Net + EfficientNet-B0 + GradCAM pipeline.

Run:
    pip install flask flask-cors torch torchvision segmentation-models-pytorch
                efficientnet_pytorch grad-cam pillow opencv-python numpy kagglehub
    python app.py

Then open http://localhost:5000
"""

import io
import os
import base64
import numpy as np
from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
from PIL import Image
import torch
import torch.nn as nn
import torchvision.transforms as transforms
import torchvision.models as models
import segmentation_models_pytorch as smp
import cv2
import kagglehub
from torchvision import datasets
from torch.utils.data import DataLoader
from efficientnet_pytorch import EfficientNet
from pytorch_grad_cam import GradCAM
from pytorch_grad_cam.utils.image import show_cam_on_image
from pytorch_grad_cam.utils.model_targets import ClassifierOutputTarget

# ─────────────────────────────────────────────
app = Flask(__name__, static_folder='.')
CORS(app)

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(f"Device: {device}")

# ─────────────────────────────────────────────
# CONFIG
# ─────────────────────────────────────────────
IMG_SIZE    = 224
NUM_CLASSES = 4
CLASS_NAMES = ["Adenocarcinoma", "Large Cell Carcinoma", "Normal", "Squamous Cell Carcinoma"]

DOCTOR_ADVICE = {
    "Adenocarcinoma": {
        "description": "Adenocarcinoma is the most common lung cancer, typically arising in peripheral lung regions. Often detected in non-smokers.",
        "advice": [
            "Immediate referral to a thoracic oncologist is strongly recommended.",
            "Molecular testing (EGFR, ALK, ROS1, PD-L1) to assess targeted therapy eligibility.",
            "Staging workup: CT chest/abdomen/pelvis, PET scan, and brain MRI.",
            "Treatment options include targeted therapy, immunotherapy, chemotherapy or surgery.",
            "Nutritional support and pulmonary rehabilitation should be initiated early.",
            "Discuss clinical trial options with your oncology team."
        ],
        "urgency": "HIGH"
    },
    "Large Cell Carcinoma": {
        "description": "Large cell carcinoma is an aggressive undifferentiated lung cancer that grows and spreads rapidly.",
        "advice": [
            "Urgent oncology consultation due to rapid growth pattern.",
            "Comprehensive staging: CT chest/abdomen/pelvis and PET-CT scan.",
            "Tissue biopsy for histological and molecular characterization.",
            "Immunotherapy (checkpoint inhibitors) may be considered as first-line therapy.",
            "Multidisciplinary tumor board review is strongly advised.",
            "Assess clinical trial eligibility — novel agents may be available."
        ],
        "urgency": "HIGH"
    },
    "Normal": {
        "description": "No malignant findings detected. Lung tissue appears within normal radiological parameters.",
        "advice": [
            "Continue annual low-dose CT screening if high-risk (age 50–80, heavy smoking history).",
            "Maintain a smoke-free lifestyle to reduce cancer risk.",
            "Regular exercise and balanced diet support long-term lung health.",
            "Report new symptoms: persistent cough, hemoptysis, or unexplained weight loss.",
            "Follow-up imaging in 12 months if any minor incidental findings noted."
        ],
        "urgency": "LOW"
    },
    "Squamous Cell Carcinoma": {
        "description": "Squamous cell carcinoma originates in central airways and is strongly linked to tobacco smoking.",
        "advice": [
            "Urgent referral to thoracic oncology and pulmonology team.",
            "Bronchoscopy to assess central airway involvement.",
            "Molecular profiling and PD-L1 testing for immunotherapy candidacy.",
            "Staging with CT, PET scan, and mediastinoscopy if indicated.",
            "Surgical resection feasible for early-stage localized disease.",
            "Smoking cessation support is essential even post-diagnosis."
        ],
        "urgency": "HIGH"
    }
}

# ─────────────────────────────────────────────
# TRANSFORMS
# ─────────────────────────────────────────────
infer_transform = transforms.Compose([
    transforms.Resize((IMG_SIZE, IMG_SIZE)),
    transforms.ToTensor(),
])

# ─────────────────────────────────────────────
# MODELS  (loaded / trained at startup)
# ─────────────────────────────────────────────
print("Loading models…")

# ── U-Net
unet = smp.Unet(
    encoder_name="resnet34",
    encoder_weights="imagenet",
    in_channels=3,
    classes=1,
).to(device)

# Load saved weights if available
SEG_WEIGHTS = "unet_lung.pth"
if os.path.exists(SEG_WEIGHTS):
    unet.load_state_dict(torch.load(SEG_WEIGHTS, map_location=device))
    print(f"  ✅ U-Net weights loaded from {SEG_WEIGHTS}")
else:
    print("  ⚠  U-Net weights not found. Run training first (train.py).")

unet.eval()

# ── EfficientNet-B0
clf_model = EfficientNet.from_pretrained("efficientnet-b0")
clf_model._fc = nn.Linear(clf_model._fc.in_features, NUM_CLASSES)
clf_model = clf_model.to(device)

CLF_WEIGHTS = "efficientnet_clf.pth"
if os.path.exists(CLF_WEIGHTS):
    clf_model.load_state_dict(torch.load(CLF_WEIGHTS, map_location=device))
    print(f"  ✅ EfficientNet weights loaded from {CLF_WEIGHTS}")
else:
    print("  ⚠  EfficientNet weights not found. Run training first (train.py).")

clf_model.eval()

print("Models ready.")

# ─────────────────────────────────────────────
# HELPERS
# ─────────────────────────────────────────────
def tensor_to_b64(arr: np.ndarray) -> str:
    """Convert numpy HxWx3 uint8 array → base64 PNG string."""
    img = Image.fromarray(arr.astype(np.uint8))
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    return base64.b64encode(buf.getvalue()).decode("utf-8")


def preprocess(pil_image: Image.Image):
    """Return (tensor on device, float32 numpy HxWxC 0–1)."""
    resized = pil_image.resize((IMG_SIZE, IMG_SIZE)).convert("RGB")
    np_img  = np.array(resized) / 255.0
    tensor  = infer_transform(pil_image).unsqueeze(0).to(device)
    return tensor, np_img.astype(np.float32)


def segment(tensor) -> np.ndarray:
    """Run U-Net, return binary mask (H×W uint8)."""
    with torch.no_grad():
        out  = unet(tensor)
        mask = torch.sigmoid(out).squeeze().cpu().numpy()
    return (mask > 0.5).astype(np.uint8)


def classify(tensor):
    """Run EfficientNet, return (pred_idx, probs array)."""
    with torch.no_grad():
        out   = clf_model(tensor)
        probs = torch.softmax(out, dim=1).cpu().numpy()[0]
    return int(np.argmax(probs)), probs


def gradcam(tensor, pred_idx: int) -> np.ndarray:
    """Return GradCAM heatmap (H×W float32 0–1)."""
    target_layers = [clf_model._conv_head]
    cam = GradCAM(model=clf_model, target_layers=target_layers)
    targets = [ClassifierOutputTarget(pred_idx)]
    gray = cam(input_tensor=tensor, targets=targets)
    return gray[0]  # (H, W)


def draw_roi(np_img: np.ndarray, binary_mask: np.ndarray) -> np.ndarray:
    """Draw bounding box around largest contour on the image."""
    vis = (np_img * 255).astype(np.uint8).copy()
    contours, _ = cv2.findContours(binary_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if contours:
        x, y, w, h = cv2.boundingRect(max(contours, key=cv2.contourArea))
        cv2.rectangle(vis, (x, y), (x+w, y+h), (0, 229, 160), 2)
        # Corner ticks
        tl = 12
        for (px, py, dx, dy) in [(x,y,1,1),(x+w,y,-1,1),(x,y+h,1,-1),(x+w,y+h,-1,-1)]:
            cv2.line(vis, (px+dx*tl, py), (px, py),         (0, 255, 179), 3)
            cv2.line(vis, (px, py),       (px, py+dy*tl),    (0, 255, 179), 3)
        cv2.rectangle(vis, (x, y-18), (x+94, y), (0, 229, 160), -1)
        cv2.putText(vis, "LUNG ROI", (x+4, y-4),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.42, (7, 13, 20), 1, cv2.LINE_AA)
        # crosshair
        cx_, cy_ = x + w//2, y + h//2
        cv2.line(vis, (cx_, y),   (cx_, y+h), (0,229,160,128), 1)
        cv2.line(vis, (x, cy_),   (x+w, cy_), (0,229,160,128), 1)
    return vis


def overlay_mask(np_img: np.ndarray, binary_mask: np.ndarray) -> np.ndarray:
    """Colour segmentation mask overlay."""
    vis = (np_img * 255).astype(np.uint8).copy()
    colored = np.zeros_like(vis)
    colored[:, :, 2] = binary_mask * 200  # blue channel
    overlay = cv2.addWeighted(vis, 0.5, colored, 0.5, 0)
    # Draw contours
    contours, _ = cv2.findContours(binary_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    cv2.drawContours(overlay, contours, -1, (0, 229, 160), 1)
    return overlay


# ─────────────────────────────────────────────
# ROUTES
# ─────────────────────────────────────────────
@app.route("/")
def index():
    return send_from_directory(".", "index.html")


@app.route("/analyze", methods=["POST"])
def analyze():
    if "image" not in request.files:
        return jsonify({"error": "No image uploaded"}), 400

    file = request.files["image"]
    try:
        pil_img = Image.open(file.stream).convert("RGB")
    except Exception as e:
        return jsonify({"error": f"Cannot open image: {e}"}), 400

    # ── Pipeline ────────────────────────────────────────
    tensor, np_img = preprocess(pil_img)

    # 1. Segmentation
    binary_mask = segment(tensor)
    seg_overlay  = overlay_mask(np_img, binary_mask)

    # 2. ROI localisation
    roi_img = draw_roi(np_img, binary_mask)

    # 3. Classification
    pred_idx, probs = classify(tensor)
    pred_class      = CLASS_NAMES[pred_idx]

    # 4. GradCAM
    cam_heatmap = gradcam(tensor, pred_idx)
    # Mask GradCAM to lung region
    mask_3ch    = np.stack([binary_mask]*3, axis=-1)
    cam_overlay = show_cam_on_image(np_img, cam_heatmap, use_rgb=True)
    cam_masked  = (cam_overlay * mask_3ch +
                   (np_img * 255 * (1 - mask_3ch))).astype(np.uint8)

    # ── Build response ──────────────────────────────────
    info = DOCTOR_ADVICE[pred_class]

    return jsonify({
        "predicted_class": pred_class,
        "confidence":      float(probs[pred_idx] * 100),
        "urgency":         info["urgency"],
        "probabilities": {
            CLASS_NAMES[i]: float(probs[i] * 100)
            for i in range(NUM_CLASSES)
        },
        "description": info["description"],
        "advice":       info["advice"],
        "images": {
            "segmentation": tensor_to_b64(seg_overlay),
            "roi":          tensor_to_b64(roi_img),
            "gradcam":      tensor_to_b64(cam_masked),
        }
    })


# ─────────────────────────────────────────────
if __name__ == "__main__":
    app.run(debug=True, port=5000)
