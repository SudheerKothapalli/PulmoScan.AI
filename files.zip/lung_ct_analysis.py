# -*- coding: utf-8 -*-
"""
LungScan AI — Integrated Lung CT Segmentation, Classification & GradCAM
=======================================================================
Colab-ready notebook. Run cells top-to-bottom.
Upload a CT scan image when prompted and get:
  - U-Net lung segmentation mask
  - Cancer type classification with probabilities
  - GradCAM heatmap overlay
  - Doctor's advice report
"""

# ─────────────────────────────────────────────
# CELL 1 — Install dependencies
# ─────────────────────────────────────────────
# !pip install -q kagglehub segmentation-models-pytorch efficientnet_pytorch grad-cam torchvision


# ─────────────────────────────────────────────
# CELL 2 — Imports
# ─────────────────────────────────────────────
import os
import io
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import cv2
import torch
import torch.nn as nn
import torchvision.transforms as transforms
import torchvision.models as models
import segmentation_models_pytorch as smp

from PIL import Image
from torchvision import datasets
from torch.utils.data import DataLoader, random_split
from efficientnet_pytorch import EfficientNet
from pytorch_grad_cam import GradCAM
from pytorch_grad_cam.utils.image import show_cam_on_image
from pytorch_grad_cam.utils.model_targets import ClassifierOutputTarget
from IPython.display import display, HTML
from google.colab import files

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(f"✅ Device: {device}")


# ─────────────────────────────────────────────
# CELL 3 — Configuration
# ─────────────────────────────────────────────
CONFIG = {
    "img_size": 224,
    "seg_encoder": "resnet34",
    "clf_models": ["resnet50", "resnet101", "googlenet", "efficientnet"],
    "num_classes": 4,
    "clf_epochs": 15,
    "seg_epochs": 20,
    "batch_size": 16,
    "lr": 1e-4,
}

CLASS_NAMES = ["Adenocarcinoma", "Large Cell Carcinoma", "Normal", "Squamous Cell Carcinoma"]

# Doctor advice per class
DOCTOR_ADVICE = {
    "Adenocarcinoma": {
        "description": "Adenocarcinoma is the most common type of lung cancer, typically found in the outer regions of the lung.",
        "advice": [
            "Immediate referral to an oncologist is strongly recommended.",
            "Molecular/genetic testing (EGFR, ALK, ROS1, PD-L1) should be performed to determine targeted therapy eligibility.",
            "Staging CT/PET scan and brain MRI are essential next steps.",
            "Treatment options may include targeted therapy, immunotherapy, chemotherapy, or surgery depending on stage.",
            "Avoid smoking and secondhand smoke exposure completely.",
            "Nutritional support and pulmonary rehabilitation should be considered.",
        ],
        "urgency": "HIGH",
        "color": "#e74c3c"
    },
    "Large Cell Carcinoma": {
        "description": "Large cell carcinoma is an undifferentiated lung cancer that can appear in any part of the lung and tends to grow quickly.",
        "advice": [
            "Urgent oncology consultation required due to aggressive growth pattern.",
            "Comprehensive staging workup including CT chest/abdomen/pelvis and PET scan.",
            "Tissue biopsy for detailed histological and molecular analysis.",
            "Immunotherapy (checkpoint inhibitors) may be a first-line option.",
            "Multidisciplinary tumor board review is recommended.",
            "Discuss clinical trial eligibility with oncologist.",
        ],
        "urgency": "HIGH",
        "color": "#c0392b"
    },
    "Normal": {
        "description": "No malignancy detected. Lung tissue appears within normal radiological parameters.",
        "advice": [
            "Continue routine annual low-dose CT screening if you are a high-risk individual (age 50-80, heavy smoker).",
            "Maintain a smoke-free lifestyle to reduce cancer risk.",
            "Regular exercise and a balanced diet support lung health.",
            "Report any new symptoms (persistent cough, hemoptysis, unexplained weight loss) to your physician.",
            "Follow-up imaging in 12 months if any incidental findings noted.",
        ],
        "urgency": "LOW",
        "color": "#27ae60"
    },
    "Squamous Cell Carcinoma": {
        "description": "Squamous cell carcinoma typically arises in the central airways and is strongly associated with smoking history.",
        "advice": [
            "Immediate referral to thoracic oncology team.",
            "Bronchoscopy may be needed to assess airway involvement.",
            "Molecular profiling and PD-L1 testing for immunotherapy candidacy.",
            "Staging with CT, PET scan, and mediastinoscopy if indicated.",
            "Surgical resection may be feasible for early-stage disease.",
            "Smoking cessation support is critical even post-diagnosis.",
        ],
        "urgency": "HIGH",
        "color": "#e67e22"
    }
}


# ─────────────────────────────────────────────
# CELL 4 — Dataset download & preparation
# ─────────────────────────────────────────────
import kagglehub

# Download segmentation dataset
print("📥 Downloading segmentation dataset...")
seg_path = kagglehub.dataset_download("kmader/finding-lungs-in-ct-data")
image_dir = os.path.join(seg_path, "2d_images")
mask_dir  = os.path.join(seg_path, "2d_masks")
print(f"   Segmentation: {len(os.listdir(image_dir))} images found")

# Download classification dataset
print("📥 Downloading classification dataset...")
clf_path = kagglehub.dataset_download("mohamedhanyyy/chest-ctscan-images")
print(f"   Classification dataset downloaded.")


# ─────────────────────────────────────────────
# CELL 5 — Transforms
# ─────────────────────────────────────────────
seg_transform = transforms.Compose([
    transforms.Resize((CONFIG["img_size"], CONFIG["img_size"])),
    transforms.ToTensor(),
])

clf_transform = transforms.Compose([
    transforms.Resize((CONFIG["img_size"], CONFIG["img_size"])),
    transforms.RandomHorizontalFlip(),
    transforms.RandomRotation(10),
    transforms.ToTensor(),
])

inference_transform = transforms.Compose([
    transforms.Resize((CONFIG["img_size"], CONFIG["img_size"])),
    transforms.ToTensor(),
])


# ─────────────────────────────────────────────
# CELL 6 — Segmentation Dataset & Model
# ─────────────────────────────────────────────
class LungDataset(torch.utils.data.Dataset):
    def __init__(self, image_dir, mask_dir, transform=None):
        self.image_dir = image_dir
        self.mask_dir  = mask_dir
        self.images    = sorted(os.listdir(image_dir))
        self.transform = transform

    def __len__(self):
        return len(self.images)

    def __getitem__(self, idx):
        img_path  = os.path.join(self.image_dir, self.images[idx])
        mask_path = os.path.join(self.mask_dir,  self.images[idx])
        image = Image.open(img_path).convert("RGB")
        mask  = Image.open(mask_path).convert("L")
        if self.transform:
            image = self.transform(image)
            mask  = self.transform(mask)
        mask = (mask > 0).float()
        return image, mask


def dice_score(pred, target, smooth=1e-6):
    pred = torch.sigmoid(pred)
    pred = (pred > 0.5).float()
    intersection = (pred * target).sum()
    return (2. * intersection + smooth) / (pred.sum() + target.sum() + smooth)


def iou_score(pred, target, smooth=1e-6):
    pred = torch.sigmoid(pred)
    pred = (pred > 0.5).float()
    intersection = (pred * target).sum()
    union = pred.sum() + target.sum() - intersection
    return (intersection + smooth) / (union + smooth)


print("🏗  Building U-Net segmentation model...")
seg_dataset    = LungDataset(image_dir, mask_dir, seg_transform)
seg_loader     = DataLoader(seg_dataset, batch_size=CONFIG["batch_size"], shuffle=True)

unet = smp.Unet(
    encoder_name="resnet34",
    encoder_weights="imagenet",
    in_channels=3,
    classes=1,
).to(device)

seg_criterion = nn.BCEWithLogitsLoss()
seg_optimizer = torch.optim.Adam(unet.parameters(), lr=CONFIG["lr"])


# ─────────────────────────────────────────────
# CELL 7 — Train U-Net
# ─────────────────────────────────────────────
print("\n🚀 Training U-Net Segmentation Model...")
loss_history, dice_history, iou_history = [], [], []

for epoch in range(CONFIG["seg_epochs"]):
    unet.train()
    total_loss = total_dice = total_iou = 0

    for images, masks in seg_loader:
        images, masks = images.to(device), masks.to(device)
        outputs = unet(images)
        loss = seg_criterion(outputs, masks)
        seg_optimizer.zero_grad()
        loss.backward()
        seg_optimizer.step()

        total_loss += loss.item()
        total_dice += dice_score(outputs, masks).item()
        total_iou  += iou_score(outputs, masks).item()

    n = len(seg_loader)
    loss_history.append(total_loss / n)
    dice_history.append(total_dice / n)
    iou_history.append(total_iou  / n)

    print(f"  Epoch {epoch+1:02d}/{CONFIG['seg_epochs']} | "
          f"Loss: {loss_history[-1]:.4f} | "
          f"Dice: {dice_history[-1]:.4f} | "
          f"IoU: {iou_history[-1]:.4f}")

torch.save(unet.state_dict(), "unet_lung.pth")
print("✅ U-Net saved → unet_lung.pth")


# ─────────────────────────────────────────────
# CELL 8 — Plot U-Net training curves
# ─────────────────────────────────────────────
fig, axes = plt.subplots(1, 3, figsize=(15, 4))
for ax, data, title, color in zip(
    axes,
    [loss_history, dice_history, iou_history],
    ["Loss", "Dice Score", "IoU Score"],
    ["#e74c3c", "#3498db", "#2ecc71"]
):
    ax.plot(data, color=color, linewidth=2)
    ax.set_title(title, fontsize=13, fontweight="bold")
    ax.set_xlabel("Epoch"); ax.grid(True, alpha=0.3)
plt.suptitle("U-Net Segmentation Training", fontsize=15, fontweight="bold")
plt.tight_layout()
plt.savefig("seg_training_curves.png", dpi=120, bbox_inches="tight")
plt.show()


# ─────────────────────────────────────────────
# CELL 9 — Classification Dataset & Models
# ─────────────────────────────────────────────
print("\n📂 Loading classification dataset...")
train_dataset = datasets.ImageFolder(os.path.join(clf_path, "Data/train"), transform=clf_transform)
val_dataset   = datasets.ImageFolder(os.path.join(clf_path, "Data/valid"), transform=inference_transform)
test_dataset  = datasets.ImageFolder(os.path.join(clf_path, "Data/test"),  transform=inference_transform)

train_loader = DataLoader(train_dataset, batch_size=CONFIG["batch_size"], shuffle=True)
val_loader   = DataLoader(val_dataset,   batch_size=CONFIG["batch_size"])
test_loader  = DataLoader(test_dataset,  batch_size=CONFIG["batch_size"])

# Override CLASS_NAMES from actual dataset folders
CLASS_NAMES = train_dataset.classes
print(f"   Classes detected: {CLASS_NAMES}")


def get_clf_model(name):
    """Build classification model with correct output head."""
    nc = CONFIG["num_classes"]
    if name == "resnet50":
        m = models.resnet50(pretrained=True)
        m.fc = nn.Linear(m.fc.in_features, nc)
    elif name == "resnet101":
        m = models.resnet101(pretrained=True)
        m.fc = nn.Linear(m.fc.in_features, nc)
    elif name == "googlenet":
        m = models.googlenet(pretrained=True)
        m.fc = nn.Linear(m.fc.in_features, nc)
    elif name == "efficientnet":
        m = EfficientNet.from_pretrained("efficientnet-b0")
        m._fc = nn.Linear(m._fc.in_features, nc)
    return m.to(device)


def train_clf_model(model, model_name):
    """Train classification model, return train/val accuracy histories."""
    criterion = nn.CrossEntropyLoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=CONFIG["lr"])
    train_hist, val_hist = [], []

    for epoch in range(CONFIG["clf_epochs"]):
        model.train()
        correct = total = 0
        for images, labels in train_loader:
            images, labels = images.to(device), labels.to(device)
            outputs = model(images)
            loss = criterion(outputs, labels)
            optimizer.zero_grad(); loss.backward(); optimizer.step()
            _, preds = torch.max(outputs, 1)
            correct += (preds == labels).sum().item()
            total   += labels.size(0)
        train_acc = 100 * correct / total
        train_hist.append(train_acc)

        model.eval()
        correct = total = 0
        with torch.no_grad():
            for images, labels in val_loader:
                images, labels = images.to(device), labels.to(device)
                outputs = model(images)
                _, preds = torch.max(outputs, 1)
                correct += (preds == labels).sum().item()
                total   += labels.size(0)
        val_acc = 100 * correct / total
        val_hist.append(val_acc)

        print(f"    [{model_name}] Epoch {epoch+1:02d} | "
              f"Train: {train_acc:.1f}% | Val: {val_acc:.1f}%")

    return train_hist, val_hist


# ─────────────────────────────────────────────
# CELL 10 — Train all classifiers
# ─────────────────────────────────────────────
print("\n🚀 Training Classification Models...")
trained_models = {}
clf_results    = {}
clf_histories  = {}

for model_name in CONFIG["clf_models"]:
    print(f"\n{'='*50}")
    print(f"  Training: {model_name.upper()}")
    print(f"{'='*50}")
    model = get_clf_model(model_name)
    t_hist, v_hist = train_clf_model(model, model_name)
    trained_models[model_name]  = model
    clf_histories[model_name]   = (t_hist, v_hist)
    clf_results[model_name]     = v_hist[-1]
    torch.save(model.state_dict(), f"{model_name}_clf.pth")
    print(f"  ✅ Saved → {model_name}_clf.pth")

best_model_name = max(clf_results, key=clf_results.get)
best_clf_model  = trained_models[best_model_name]
print(f"\n🏆 Best model: {best_model_name.upper()} "
      f"({clf_results[best_model_name]:.2f}% val accuracy)")


# ─────────────────────────────────────────────
# CELL 11 — Evaluate best model on test set
# ─────────────────────────────────────────────
from sklearn.metrics import confusion_matrix, classification_report, roc_curve, auc
from sklearn.preprocessing import label_binarize
import seaborn as sns

def evaluate_model(model):
    model.eval()
    all_preds, all_labels, all_probs = [], [], []
    correct = total = 0
    with torch.no_grad():
        for images, labels in test_loader:
            images, labels = images.to(device), labels.to(device)
            outputs = model(images)
            probs   = torch.softmax(outputs, dim=1)
            _, preds = torch.max(outputs, 1)
            correct += (preds == labels).sum().item()
            total   += labels.size(0)
            all_preds.extend(preds.cpu().numpy())
            all_labels.extend(labels.cpu().numpy())
            all_probs.extend(probs.cpu().numpy())
    return (100 * correct / total,
            np.array(all_labels),
            np.array(all_preds),
            np.array(all_probs))

acc, labels, preds, probs = evaluate_model(best_clf_model)
print(f"\n📊 {best_model_name.upper()} Test Accuracy: {acc:.2f}%")
print("\nClassification Report:")
print(classification_report(labels, preds, target_names=CLASS_NAMES))


# ─────────────────────────────────────────────
# CELL 12 — Confusion matrix & ROC curves
# ─────────────────────────────────────────────
fig, axes = plt.subplots(1, 2, figsize=(14, 5))

# Confusion matrix
cm = confusion_matrix(labels, preds)
sns.heatmap(cm, annot=True, fmt="d", cmap="Blues",
            xticklabels=CLASS_NAMES, yticklabels=CLASS_NAMES, ax=axes[0])
axes[0].set_xlabel("Predicted"); axes[0].set_ylabel("Actual")
axes[0].set_title(f"Confusion Matrix — {best_model_name.upper()}", fontweight="bold")

# ROC curves
y_bin = label_binarize(labels, classes=list(range(len(CLASS_NAMES))))
colors = ["#e74c3c", "#3498db", "#2ecc71", "#f39c12"]
for i, (cls, col) in enumerate(zip(CLASS_NAMES, colors)):
    fpr, tpr, _ = roc_curve(y_bin[:, i], probs[:, i])
    axes[1].plot(fpr, tpr, label=f"{cls} (AUC={auc(fpr,tpr):.2f})", color=col, lw=2)
axes[1].plot([0,1],[0,1],"k--", lw=1)
axes[1].set_xlabel("False Positive Rate"); axes[1].set_ylabel("True Positive Rate")
axes[1].set_title("ROC Curves — All Classes", fontweight="bold"); axes[1].legend()

plt.tight_layout()
plt.savefig("evaluation_plots.png", dpi=120, bbox_inches="tight")
plt.show()


# ─────────────────────────────────────────────
# CELL 13 — GradCAM setup helper
# ─────────────────────────────────────────────
def get_gradcam_target_layer(model, model_name):
    """Return the correct last convolutional layer for GradCAM per model."""
    if model_name in ("resnet50", "resnet101"):
        return [model.layer4[-1]]
    elif model_name == "googlenet":
        return [model.inception5b]
    elif model_name == "efficientnet":
        # Last Conv layer before pooling
        return [model._conv_head]
    else:
        raise ValueError(f"Unknown model: {model_name}")


def compute_gradcam(model, model_name, input_tensor, target_class):
    """Return GradCAM heatmap (H×W numpy array, 0–1)."""
    target_layers = get_gradcam_target_layer(model, model_name)
    cam = GradCAM(model=model, target_layers=target_layers)
    targets = [ClassifierOutputTarget(target_class)]
    grayscale_cam = cam(input_tensor=input_tensor, targets=targets)
    return grayscale_cam[0]  # shape (H, W)


# ─────────────────────────────────────────────
# CELL 14 — Full inference pipeline function
# ─────────────────────────────────────────────
def analyze_ct_scan(image_path,
                    unet_model, clf_model, clf_model_name,
                    class_names=CLASS_NAMES,
                    threshold=0.5):
    """
    Full pipeline:
      1. Load & preprocess CT image
      2. U-Net segmentation → lung mask
      3. Classifier → cancer type + probabilities
      4. GradCAM → heatmap on predicted class
      5. Rich visualisation + doctor's report
    """
    # ── 1. Load image ──────────────────────────────────────────────────────
    pil_img = Image.open(image_path).convert("RGB")
    original_np = np.array(pil_img.resize((CONFIG["img_size"], CONFIG["img_size"]))) / 255.0

    tensor = inference_transform(pil_img).unsqueeze(0).to(device)   # (1,3,H,W)

    # ── 2. Segmentation ────────────────────────────────────────────────────
    unet_model.eval()
    with torch.no_grad():
        seg_out = unet_model(tensor)
    seg_mask = torch.sigmoid(seg_out).squeeze().cpu().numpy()        # (H,W) 0-1
    binary_mask = (seg_mask > threshold).astype(np.uint8)

    # Contour detection for localisation box
    contours, _ = cv2.findContours(binary_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    box_img = (original_np * 255).astype(np.uint8).copy()
    if contours:
        x, y, w, h = cv2.boundingRect(max(contours, key=cv2.contourArea))
        cv2.rectangle(box_img, (x, y), (x+w, y+h), (0, 255, 0), 2)
        cv2.putText(box_img, "Lung ROI", (x, max(y-5, 10)),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 1)

    # ── 3. Classification ──────────────────────────────────────────────────
    clf_model.eval()
    with torch.no_grad():
        clf_out   = clf_model(tensor)
        clf_probs = torch.softmax(clf_out, dim=1).cpu().numpy()[0]   # (num_classes,)
    pred_idx   = int(np.argmax(clf_probs))
    pred_class = class_names[pred_idx]
    pred_prob  = clf_probs[pred_idx] * 100

    # ── 4. GradCAM ─────────────────────────────────────────────────────────
    grayscale_cam = compute_gradcam(clf_model, clf_model_name, tensor, pred_idx)
    gradcam_overlay = show_cam_on_image(original_np.astype(np.float32),
                                        grayscale_cam, use_rgb=True)

    # GradCAM masked to lung region (highlight only inside lung)
    mask_3ch     = np.stack([binary_mask]*3, axis=-1)
    gradcam_lung = gradcam_overlay * mask_3ch + \
                   (original_np * 255 * (1 - mask_3ch)).astype(np.uint8)

    # ── 5. Visualisation ────────────────────────────────────────────────────
    info = DOCTOR_ADVICE.get(pred_class, DOCTOR_ADVICE["Normal"])

    fig = plt.figure(figsize=(20, 12))
    fig.patch.set_facecolor("#0d1117")

    title_color = "#ffffff"
    sub_color   = "#aaaaaa"

    # Row 1: 4 image panels
    panel_titles = ["Original CT Scan", "Segmentation Mask",
                    "Lung ROI Localisation", f"GradCAM — {pred_class}"]
    panel_imgs   = [
        (original_np * 255).astype(np.uint8),
        (seg_mask * 255).astype(np.uint8),
        box_img,
        gradcam_lung.astype(np.uint8),
    ]
    cmaps = [None, "hot", None, None]

    for i, (title, img, cmap) in enumerate(zip(panel_titles, panel_imgs, cmaps)):
        ax = fig.add_subplot(2, 4, i+1)
        ax.imshow(img, cmap=cmap)
        ax.set_title(title, color=title_color, fontsize=11, fontweight="bold", pad=6)
        ax.axis("off")
        ax.set_facecolor("#0d1117")

    # Row 2 left: probability bar chart
    ax_bar = fig.add_subplot(2, 4, (5, 6))
    bar_colors = ["#e74c3c" if i == pred_idx else "#3d5a80"
                  for i in range(len(class_names))]
    bars = ax_bar.barh(class_names, clf_probs * 100, color=bar_colors, height=0.5)
    ax_bar.set_xlim(0, 100)
    ax_bar.set_xlabel("Probability (%)", color=sub_color, fontsize=10)
    ax_bar.set_title("Classification Probabilities", color=title_color,
                     fontsize=11, fontweight="bold")
    ax_bar.tick_params(colors=sub_color)
    ax_bar.set_facecolor("#161b22")
    ax_bar.spines[:].set_color("#30363d")
    for bar, prob in zip(bars, clf_probs):
        ax_bar.text(bar.get_width() + 1, bar.get_y() + bar.get_height()/2,
                    f"{prob*100:.1f}%", va="center", color=title_color, fontsize=9)

    # Row 2 right: diagnosis card
    ax_diag = fig.add_subplot(2, 4, (7, 8))
    ax_diag.set_facecolor("#161b22")
    ax_diag.axis("off")

    urgency = info["urgency"]
    urg_color = "#e74c3c" if urgency == "HIGH" else "#2ecc71"

    diag_text = (
        f"DIAGNOSIS SUMMARY\n"
        f"{'─'*38}\n"
        f"Predicted Class : {pred_class}\n"
        f"Confidence      : {pred_prob:.1f}%\n"
        f"Urgency Level   : {urgency}\n"
        f"Model Used      : {clf_model_name.upper()}\n\n"
        f"About:\n{info['description']}\n\n"
        f"Key Recommendations:\n"
    )
    for j, advice in enumerate(info["advice"][:4], 1):
        diag_text += f"  {j}. {advice}\n"

    ax_diag.text(0.03, 0.97, diag_text, transform=ax_diag.transAxes,
                 fontsize=8.5, va="top", ha="left", color=title_color,
                 fontfamily="monospace",
                 bbox=dict(boxstyle="round,pad=0.5", facecolor="#1c2333",
                           edgecolor=urg_color, linewidth=2))

    # Main title
    fig.suptitle(
        f"LungScan AI  |  {pred_class}  |  Confidence: {pred_prob:.1f}%",
        fontsize=16, fontweight="bold", color=title_color, y=1.01
    )

    plt.tight_layout()
    out_path = "lung_analysis_result.png"
    plt.savefig(out_path, dpi=150, bbox_inches="tight",
                facecolor=fig.get_facecolor())
    plt.show()
    print(f"\n✅ Result saved → {out_path}")

    # ── Console summary ────────────────────────────────────────────────────
    print("\n" + "="*60)
    print(f"  🫁 LUNG ANALYSIS REPORT")
    print("="*60)
    print(f"  Predicted Condition : {pred_class}")
    print(f"  Confidence          : {pred_prob:.1f}%")
    print(f"  Urgency             : {urgency}")
    print(f"\n  About: {info['description']}")
    print(f"\n  Doctor's Advice:")
    for j, adv in enumerate(info["advice"], 1):
        print(f"    {j}. {adv}")
    print("="*60)

    return {
        "predicted_class": pred_class,
        "confidence": pred_prob,
        "all_probs": dict(zip(class_names, (clf_probs * 100).tolist())),
        "urgency": urgency,
        "segmentation_mask": seg_mask,
        "gradcam_heatmap": grayscale_cam,
    }


# ─────────────────────────────────────────────
# CELL 15 — Upload & Analyze your CT scan
# ─────────────────────────────────────────────
print("📤 Please upload a CT scan image (JPG/PNG)...")
uploaded = files.upload()

for filename in uploaded.keys():
    print(f"\n🔍 Analyzing: {filename}")
    result = analyze_ct_scan(
        image_path      = filename,
        unet_model      = unet,
        clf_model       = best_clf_model,
        clf_model_name  = best_model_name,
    )


# ─────────────────────────────────────────────
# CELL 16 — Download result image
# ─────────────────────────────────────────────
files.download("lung_analysis_result.png")
print("✅ Result downloaded.")


# ─────────────────────────────────────────────
# CELL 17 — (Optional) Analyse a specific sample from the test set
# ─────────────────────────────────────────────
def analyze_test_sample(sample_idx=0):
    """Run full pipeline on a sample from the test dataset."""
    img_tensor, true_label = test_dataset[sample_idx]
    img_pil = transforms.ToPILImage()(img_tensor)
    tmp_path = f"test_sample_{sample_idx}.png"
    img_pil.save(tmp_path)

    print(f"True label: {CLASS_NAMES[true_label]}")
    result = analyze_ct_scan(
        image_path     = tmp_path,
        unet_model     = unet,
        clf_model      = best_clf_model,
        clf_model_name = best_model_name,
    )
    return result

# Uncomment to test on a dataset sample:
# analyze_test_sample(sample_idx=5)
